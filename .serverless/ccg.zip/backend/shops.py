def create_shop(shop_url, shop_token):
    return {}


def get_shop(shop_url):
    return {}


def update_shop(shop):
    return {}
