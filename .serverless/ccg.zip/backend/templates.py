def create_template(new_template):
    return new_template


def get_template(template_id):
    return {}


def get_templates(shop_url):
    return []


def update_template(updates):
    return {}
